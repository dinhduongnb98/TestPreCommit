import blackd

blackd.patched_main()
