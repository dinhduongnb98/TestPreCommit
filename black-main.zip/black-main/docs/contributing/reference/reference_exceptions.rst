*Black* exceptions
==================

*Contents are subject to change.*

.. currentmodule:: black

.. autoexception:: black.linegen.CannotSplit

.. autoexception:: black.NothingChanged

.. autoexception:: black.InvalidInput
