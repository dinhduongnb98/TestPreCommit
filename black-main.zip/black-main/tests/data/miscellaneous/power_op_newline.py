importA;()<<0**0#

# output

importA
(
    ()
    << 0
    ** 0
)  #
