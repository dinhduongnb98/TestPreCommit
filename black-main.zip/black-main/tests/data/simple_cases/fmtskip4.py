a =   2
# fmt: skip
l = [1, 2, 3,]

# output

a = 2
# fmt: skip
l = [
    1,
    2,
    3,
]