\





print("hello, world")

# output


print("hello, world")
